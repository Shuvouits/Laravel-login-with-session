<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class ProfileController extends Controller
{
    //

    public function index(Request $req)
    {
        $email = $req->input('email');
        $password = $req->input('password');
    
        $get_data = "SELECT * FROM users WHERE email = '$email' AND password = $password ";
        $run_data = DB::select($get_data);

        $count = count($run_data);
        if($count==1)
        {
            session()->put('email',$email);
            $email = session()->get('email');
            return view('profile',compact('email'));
        }else{
            return view('index');
        }
    }

    public function logout(Request $req){
        
        session()->forget('email');
        return view('index');
    }
}
