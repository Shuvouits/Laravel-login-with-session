<!DOCTYPE html>
<html>
<head>
	<title>Profile Page</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<div class="row jumbotron">
			<div class="col-md-12">
				<h3 class="text-center" style="font-weight: bold"><?php echo e($email); ?></h3>
			</div>
			<div class="col-md-12 text-center">
				<form action="logout" method="post">
					<?php echo e(@csrf_field()); ?>

					<input type="submit" name="submit" value="Logout" class="btn btn-primary">
					
				</form>
			</div>
		</div>
	</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\laravel_test\laravel\resources\views/profile.blade.php ENDPATH**/ ?>