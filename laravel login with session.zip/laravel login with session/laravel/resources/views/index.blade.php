<!DOCTYPE html>
<html>
<head>
	<title>Laravel Login Page</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<div class="row jumbotron">
			<div class="col-md-12">
				<h3 class="text-center" style="font-weight: bold">Laravel Login Page</h3>
			</div>
			<div class="col-md-6 col-md-offset-3">
				<form action="profile" method="post">
					{{@csrf_field()}}
					<div class="form-group">
						<div class="col-md-2">
							<label>Email:</label>
						</div>
						<div class="col-md-10">
							<input type="email" name="email" class="form-control" placeholder="Enter your Email.....">
						</div>
						
					</div>

					<br>
					<br>
					<br>

					<div class="form-group">
						<div class="col-md-2">
							<label>Password:</label>
						</div>
						<div class="col-md-10">
							<input type="password" name="password" class="form-control" placeholder="**********">
						</div>
						
					</div>
					<br>
					<br>
					<div class="col-md-12 text-center">
						<input type="submit" name="submit" class="btn btn-primary">
						
					</div>
					
					
				</form>
			</div>
		</div>
	</div>

</body>
</html>